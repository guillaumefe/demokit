"""
Demokit: A demo kit for Python projects.
"""

__version__ = "1.0.7"
